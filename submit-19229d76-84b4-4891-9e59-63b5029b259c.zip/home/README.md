Project 1:

In this project, We'll apply the concepts learned in data modeling with Postgres and build an ETL pipeline using Python. We will define fact and dimension tables for a star schema for a particular analytic focus, and write an ETL pipeline that transfers data from files in two local directories into these tables in Postgres using Python and SQL.

We created a Postgres database from the two JSON directories. We extracted data from two directories, applied transformation, filtering, and then inserting the transformed data into appropriate tables.
This data can now be used for ad-hoc queries, basic aggregation and analytics purposes.